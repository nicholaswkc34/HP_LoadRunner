Test()
{

	web_url("favicon.ico", 
		"URL=http://35.196.208.144:8181/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=", 
		"Snapshot=t40.inf", 
		LAST);

	return 0;
}