Browse()
{

	web_url("favicon.ico", 
		"URL=http://35.196.208.144:8181/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	lr_start_transaction("1_transaction");

	lr_end_transaction("1_transaction",LR_AUTO);

	return 0;
}